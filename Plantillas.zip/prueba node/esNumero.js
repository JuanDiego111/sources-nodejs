function esNumeros(cadena){
    if (isNaN(cadena)==true){
        return false
    }
    else if(isNaN(cadena)==false){
        return true
    }
}

export default esNumeros