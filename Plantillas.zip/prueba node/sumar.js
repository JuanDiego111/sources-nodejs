import sumar from "./mate2"
import n2f from "num2fraction"
import esNumeros from "./esNumero"
console.log(sumar(5,8));
console.log(n2f(2.5))
console.log(esNumeros('uno'))
console.log(esNumeros("uno"))
console.log(esNumeros(`uno`))
console.log(esNumeros('1'))
console.log(esNumeros('1.0'))
console.log(esNumeros('1.00000'))
console.log(esNumeros('1000000'))
console.log(esNumeros('01'))
console.log(esNumeros(99))
console.log(esNumeros(1))
console.log(esNumeros(4))
console.log(esNumeros(9))
console.log(esNumeros(19))