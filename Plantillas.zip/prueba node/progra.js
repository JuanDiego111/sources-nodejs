let a=2
a++
function sumar(a,b){
    return a+b
}

a+= sumar(a,5)

console.log('El valor de a:' + a)