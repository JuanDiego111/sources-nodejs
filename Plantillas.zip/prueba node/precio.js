function calcularPrecio(edad,promocion){
            if (edad<13){
            return 'Precio $ 00.00'    
        }
        else if (edad>64){
            return 'Precio $ 60.00'
        }
        else if(promocion==true){
            return 'Precio $ 70.00'
        }
        return 'Precio $ 100.00'
}

console.log(calcularPrecio(13,false))