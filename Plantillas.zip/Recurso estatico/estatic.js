const express=require('express');
const fun=express()

fun.use('/static',express.static('assets'))

fun.get('/inicio',(pet,req)=>{

    req.sendFile(__dirname+'/page/inicio.html')
})

fun.set('view engine','ejs')
fun.get('/titulos', (pet,req)=>{
    req.render("pages/index",{nombre:"luis"})
})

fun.get('/',(pet,req)=>{
    req.send('Bienvenido')
});

fun.listen(8080,()=>{
    console.log('Servidor iniciado');
});