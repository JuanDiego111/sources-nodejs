const express=require('express')
const fun=express()
const bodyParser=require('body-parser')

fun.use(bodyParser.json())
fun.use(bodyParser.urlencoded({extended:true}))

fun.get("/",(pet,res)=>{
    res.send(`Bienvenido ${pet.query.orden}`)
})



fun.get("/:cliente/:orden",(pet,res)=>{
    res.send(`Bienvenido ${pet.params.cliente} ${pet.params.orden}`)
})

fun.get("/:c/:o/:b/:n",(pet,res)=>{
    res.send(`Bienvenido a la ${pet.params.b} ${pet.params.n} del ${pet.params.c} ${pet.params.o} orden ${pet.query.orden}`)
})

fun.get("/:a/:d/:f/:g",(pet,res)=>{
    res.send(`Bienvenido a la ${pet.params.f} ${pet.params.g} del ${pet.params.a} ${pet.params.d} orden ${pet.query.orden}`)
})



fun.get("/persona/:id",(pet,res)=>{
    res.send(`Bienvenido ${pet.params.id}`)
})
fun.post("/procesar",function(pet,res){
    res.send(`Correo ${pet.body.Email} 
    Contraseña ${pet.body.Password}
    Check ${pet.body.Check}`)

})

fun.post("/valido",function(pet,res){
    let re;
    re = /^[^ ]{6,}/
    if (!re.test(pet.body.Password)){
      res.send("ERROR")
      return
    }
    re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (!re.test(pet.body.Email)){
      res.send("ERROR")
      return
    }
    res.send("OK")
})

fun.set("view engine","ejs")
fun.get("/Tienda",(pet,res)=>{
    res.render("details/index")
})

fun.get("/formulario",(pet,res)=>{
    res.render("pages/form")
})

fun.get("/validar",(pet,res)=>{
    res.render("pages/formval")
})


fun.listen(8080,function(){
    console.log("Servidor Iniciado")
})