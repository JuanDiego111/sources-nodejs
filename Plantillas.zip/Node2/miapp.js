var express = require('express')
var aplicacion = express()
aplicacion.get('/',(peticion,respuesta)=>{
    respuesta.type('html');
    respuesta.send(`<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body>
        <h1 id="saludo"></h1>
    </body>
    <script>
        function saludos(){
           var x=Math.random();
           if (x<=(1/2)){
               return "Bienvenido!"
           }
           else if (x>(1/2)){
               return "Hola!"
           }
        }
        
        setInterval(function(){
        var saludo=document.getElementById("saludo")
        saludo.innerHTML=saludos()
        },
         3000);
         
    </script>
    </html>`)
})
aplicacion.get('/despedida',(peticion,respuesta)=>{
    respuesta.set('Content-Type','text/html');
    respuesta.sendFile(__dirname+"/public/despedida.html")
})
aplicacion.listen(8080,()=>{console.log("Servidor Iniciado");
})