const express=require('express')
const app=express()
const mysql = require('mysql2');
const bodyParser = require('body-parser')

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'Xeraton246810',
  database: 'bodeganodejs',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))

app.get("/api/productos", function (pet,res) { 
    pool.getConnection(function (err,connec) {
        const query=`SELECT * FROM productos `
        connec.query(query, function (err,filas,campos) {
            res.json({data:filas})        
        })        
        connec.release()
    })

 })

 app.get("/api/productos/:id", function (pet,res) { 
    pool.getConnection(function (err,connec) {
        const query=`SELECT * FROM productos  WHERE id=${connec.escape(pet.params.id)}`
        connec.query(query, function (err,filas,campos) {
           if (filas.length>0){ 
               res.json({data:filas[0]})}
            else {
                res.status(404)
                res.send({error:["no se encuentra"]})
            }        
        })        
        connec.release()
    })

 })


app.post('/api/productos', function (pet,res) { 
    pool.getConnection( function (err,connec) { 
        const query = `INSERT INTO productos VALUES (NULL, ${connec.escape(pet.body.nombre)}, ${connec.escape(pet.body.cantidad)})`
        console.log(query)
        connec.query(query, function (error,filas,campos) { 
            const nuevoId=filas.insertId
            console.log(nuevoId)
            const queryConsulta = `SELECT * FROM productos WHERE id=${connec.escape(nuevoId)}`
            console.log(queryConsulta)
            connec.query(queryConsulta, function (error,filas,campos) {
                res.status(201)
                res.json({data: filas[0]})                
            })
         })
         connec.release()
     } )
 })




app.listen(8080, function(){
    console.log("Inventario en linea")
})