const express=require('express');
const fun=express();

fun.set('view engine','pug');

fun.get('/',function(req,res){
    res.render('pages/index');
});

fun.listen(8080,()=>{
    console.log("servidor iniciado")
})
